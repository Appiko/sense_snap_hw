		::Sense_rev3 Gerber file details::

1. List of file identification
	Sense_rev3.GTL -> Top Layer
	Sense_rev3.GBL -> Bottom Layer
	Sense_rev3.GTS -> Top Soldermask
	Sense_rev3.GBS -> Bottom Soldermask
	Sense_rev3.GTO -> Top Silkscreen
	Sense_rev3.GBO -> Bottom Silkscreen
	Sense_rev3.GM1 -> Board Outline
	Sense_rev3.DRD -> Drills

2. NPTH holes - M3 size